const slider = document.getElementById('slider');
const prevArrow = document.querySelector('.prev');
const nextArrow = document.querySelector('.next');
let currentIndex = 0;

function moveSlider(direction) {
    const slides = slider.children;
    const totalSlides = slides.length;

    slides[currentIndex].classList.remove('active');
    currentIndex += direction;

    if (currentIndex < 0) {
        currentIndex = totalSlides - 1;
    } else if (currentIndex >= totalSlides) {
        currentIndex = 0;
    }

    slides[currentIndex].classList.add('active');
    adjustSliderHeight();
}

function checkSlideCount() {
    const totalSlides = slider.children.length;
    if (totalSlides <= 1) {
        prevArrow.style.display = 'none';
        nextArrow.style.display = 'none';
    } else {
        prevArrow.style.display = 'inline-flex';
        nextArrow.style.display = 'inline-flex';
    }
}

function adjustSliderHeight() {
    const activeSlide = slider.children[currentIndex];
    const activeHeight = activeSlide.offsetHeight;
    slider.style.height = `${activeHeight}px`;
}

function initializeSlider() {
    slider.children[currentIndex].classList.add('active');
    adjustSliderHeight();
}

initializeSlider();
checkSlideCount();
