<?php
namespace CarlyleBlockTheme;

class RumspeedThemeUpdater {
    /**
     * The theme current version
     * @var string
     */
    private $current_version;

    /**
     * The theme remote update path
     * @var string
     */
    private $update_path;

    /**
     * Theme name (theme folder)
     * @var string
     */
    private $slug;

    /**
     * License User
     * @var string
     */
    private $license_user;

    /**
     * License Key
     * @var string
     */
    private $license_key;




    /**
     * Initialize a new instance of the WordPress Auto-Update class
     * @param string $slug
     * @param string $version
     * @param string $updater_url
     * @param string $license_user
     * @param string $license_key
     */
    public function __construct( $slug, $version, $updater_url, $license_user, $license_key ) {

        // set the class public variables
        $this->slug            = $slug;
        $this->current_version = $version;
        $this->update_path     = $updater_url;

        // set the License
        $this->license_user    = $license_user;
        $this->license_key     = $license_key;

        // define the alternative API for updating checking
        add_filter( 'site_transient_update_themes', array( &$this, 'check_update' ) );
    }




    /**
     * Add our self-hosted autoupdate theme to the filter transient
     *
     * @param $transient
     * @return object $transient
     */
    public function check_update( $transient ) {

        if ( ! $transient ) {
            return false;
        }

        $transient_name = $this->slug . '-version-check';

        // trying to get from cache first
        if ( false == $remote = get_transient( $transient_name ) ) {

            // get the remote version
            $remote = $this->getRemote( 'theme_check' );

            if ( ! $remote ) {
                return $transient;
            }

            set_transient( $transient_name, $remote, HOUR_IN_SECONDS  );
        }

        $remote = (object) maybe_unserialize($remote);
        
        $data = [
            'theme' => $this->slug,
            'url' => $remote->details_url,
            'requires' => $remote->requires,
            'requires_php' => $remote->requires_php,
            'new_version' => $remote->version,
            'package' => $remote->download_url,
        ];
    
        // version check
        if (
            $remote
            && version_compare( $this->current_version, $remote->version, '<' )
            && version_compare( $remote->requires, get_bloginfo( 'version' ), '<' )
            && version_compare( $remote->requires_php, PHP_VERSION, '<' )
        ) {
            $transient->response[ $this->slug ] = $data;
        } else {
            $transient->no_update[ $this->slug ] = $data;
        }
    
        return $transient;
    }




    /**
     * Get Remote POST Request Body
     * 
     * @param array $action
     * @return bool|string $request
     */
    public function getRemote( $action ) {

        // set the request parameters
        $params = [
            'headers' => [
                'Content-Type' => 'application/x-www-form-urlencoded',
                'Referer'      => home_url(),
            ],
            'body' => [
                'action'       => $action,
                'theme_name'   => $this->slug,
                'license_user' => $this->license_user,
                'license_key'  => $this->license_key,
            ],
        ];

        // Make the POST request
        $request = wp_remote_post( $this->update_path, $params );

        // Check if response is valid
        if ( ! is_wp_error( $request ) || wp_remote_retrieve_response_code( $request ) === 200 ) {
            return @unserialize( $request['body'] );
        }
        
        return false;
    }
}