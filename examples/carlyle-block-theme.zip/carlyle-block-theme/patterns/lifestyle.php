<?php
/**
 * Title: lifestyle
 * Slug: carlyle-block-theme/lifestyle
 * Categories: hidden
 * Inserter: no
 */
?>
<!-- wp:template-part {"slug":"header","tagName":"header"} /-->

<!-- wp:pattern {"slug":"carlyle-block-theme/featured-coverstrip"} /-->
<!-- wp:pattern {"slug":"carlyle-block-theme/content-image-right"} /-->
 <!-- wp:pattern {"slug":"carlyle-block-theme/featured-ammenities"} /-->
 <!-- wp:pattern {"slug":"carlyle-block-theme/content-image-rightbackground"} /-->
 <!-- wp:pattern {"slug":"carlyle-block-theme/contactfullwidth"} /-->

 <!-- wp:template-part {"slug":"footer","area":"footer"} /-->