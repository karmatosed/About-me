<?php
/**
 * Title: Featured Homes
 * Slug: carlyle-block-theme/available-homes-featured
 * Categories: carlyleblocktheme-content
 * Viewport Width: 1240
 * Inserter: false
 */
?>
<!-- wp:group {"layout":{"type":"constrained","contentSize":"1240px"}} -->
<div class="wp-block-group">
    <!-- wp:heading {"style":{"elements":{"link":{"color":{"text":"var:preset|color|accent-3"}}}},"textColor":"accent-3"} -->
    <h2 class="wp-block-heading has-accent-3-color has-text-color has-link-color">Featured Homes</h2>
    <!-- /wp:heading -->

    <!-- wp:shortcode -->
    [carlyle_home_listings featured=3]
    <!-- /wp:shortcode -->
</div>
<!-- /wp:group -->