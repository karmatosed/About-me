<?php
/**
 * Title: index
 * Slug: carlyle-block-theme/index
 * Categories: hidden
 * Inserter: no
 */
?>
<!-- wp:template-part {"slug":"header","tagName":"header"} /-->

<!-- wp:group {"style":{"spacing":{"margin":{"top":"0px","bottom":"0px"}}},"backgroundColor":"neutral","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-neutral-background-color has-background" style="margin-top:0px;margin-bottom:0px"><!-- wp:cover {"url":"<?php echo esc_url( get_stylesheet_directory_uri() ); ?>/assets/videos/GettyImages-629177256.mp4","dimRatio":60,"overlayColor":"contrast","isUserOverlayColor":true,"backgroundType":"video","minHeight":100,"minHeightUnit":"vh","align":"full","style":{"spacing":{"margin":{"top":"0px","bottom":"0px"},"padding":{"top":"var:preset|spacing|30","bottom":"var:preset|spacing|30"}},"border":{"width":"1px","color":"#ffffff","radius":{"bottomLeft":"50px","bottomRight":"50px"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-cover alignfull has-border-color" style="border-color:#ffffff;border-width:1px;border-bottom-left-radius:50px;border-bottom-right-radius:50px;margin-top:0px;margin-bottom:0px;padding-top:var(--wp--preset--spacing--30);padding-bottom:var(--wp--preset--spacing--30);min-height:100vh"><span aria-hidden="true" class="wp-block-cover__background has-contrast-background-color has-background-dim-60 has-background-dim"></span><video class="wp-block-cover__video-background intrinsic-ignore" autoplay muted loop playsinline src="<?php echo esc_url( get_stylesheet_directory_uri() ); ?>/assets/videos/GettyImages-629177256.mp4" data-object-fit="cover"></video><div class="wp-block-cover__inner-container"><!-- wp:group {"align":"wide","layout":{"type":"constrained","justifyContent":"left"}} -->
<div class="wp-block-group alignwide"><!-- wp:heading {"level":1,"style":{"elements":{"link":{"color":{"text":"var:preset|color|base"}}}},"textColor":"base"} -->
<h1 class="wp-block-heading has-base-color has-text-color has-link-color"><?php esc_html_e('Embrace the Allure of 55+ Living', 'carlyle-block-theme');?></h1>
<!-- /wp:heading -->

<!-- wp:buttons {"fontSize":"tiny"} -->
<div class="wp-block-buttons has-custom-font-size has-tiny-font-size"><!-- wp:button {"backgroundColor":"accent","textColor":"base","style":{"elements":{"link":{"color":{"text":"var:preset|color|base"}}}}} -->
<div class="wp-block-button"><a class="wp-block-button__link has-base-color has-accent-background-color has-text-color has-background has-link-color wp-element-button"><?php esc_html_e('Our Listings', 'carlyle-block-theme');?></a></div>
<!-- /wp:button -->

<!-- wp:button {"textColor":"contrast","style":{"color":{"background":"#e8e8e8bf"},"elements":{"link":{"color":{"text":"var:preset|color|contrast"}}}},"fontFamily":"graphik"} -->
<div class="wp-block-button has-graphik-font-family"><a class="wp-block-button__link has-contrast-color has-text-color has-background has-link-color wp-element-button" style="background-color:#e8e8e8bf"><?php esc_html_e('Contact Us', 'carlyle-block-theme');?></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div></div>
<!-- /wp:cover --></div>
<!-- /wp:group -->

<!-- wp:group {"layout":{"type":"constrained","contentSize":"1240px"}} -->
<div class="wp-block-group"><!-- wp:shortcode -->
[carlyle_home_listings home_count=3]
<!-- /wp:shortcode --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="padding-top:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40)"><!-- wp:group {"align":"wide","layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group alignwide"><!-- wp:image {"width":"564px","height":"auto","sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="<?php echo esc_url( get_stylesheet_directory_uri() ); ?>/assets/images/GettyImages-956560038.jpg" alt="<?php esc_html_e('', 'carlyle-block-theme');?>" style="width:564px;height:auto"/></figure>
<!-- /wp:image -->

<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:query {"queryId":4,"query":{"perPage":10,"pages":0,"offset":0,"postType":"post","order":"desc","orderBy":"date","author":"","search":"","exclude":[],"sticky":"","inherit":true}} -->
<div class="wp-block-query"><!-- wp:post-template -->
<!-- wp:post-title /-->

<!-- wp:post-date /-->
<!-- /wp:post-template -->

<!-- wp:query-pagination -->
<!-- wp:query-pagination-previous /-->

<!-- wp:query-pagination-numbers /-->

<!-- wp:query-pagination-next /-->
<!-- /wp:query-pagination -->

<!-- wp:query-no-results -->
<!-- wp:paragraph {"placeholder":"Add text or blocks that will display when a query returns no results."} -->
<p><?php esc_html_e('', 'carlyle-block-theme');?></p>
<!-- /wp:paragraph -->
<!-- /wp:query-no-results --></div>
<!-- /wp:query -->

<!-- wp:heading {"fontSize":"large"} -->
<h2 class="wp-block-heading has-large-font-size"><?php esc_html_e('ELEVATED MANUFACTURED HOME LIVING!&nbsp;', 'carlyle-block-theme');?></h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"tiny"} -->
<p class="has-tiny-font-size"><?php esc_html_e('Nothing beats that bright blue Idaho sky!', 'carlyle-block-theme');?></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"fontSize":"tiny"} -->
<p class="has-tiny-font-size"><?php esc_html_e('When you join Ridgeview at Coeur D’Alene, you experience a welcoming manufactured home community in a great area with all the amenities you could want. Plenty of greenspaces exist to practice daily exercise, walk, picnic with neighbors, or watch grandkids play. Do you have a four-legged friend coming along for the journey? Our 55+ community is pet-friendly, ensuring your furry family member is there for every holiday, experience, and celebration.', 'carlyle-block-theme');?></p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"backgroundColor":"accent","textColor":"base","style":{"elements":{"link":{"color":{"text":"var:preset|color|base"}}}},"fontSize":"tiny"} -->
<div class="wp-block-button has-custom-font-size has-tiny-font-size"><a class="wp-block-button__link has-base-color has-accent-background-color has-text-color has-background has-link-color wp-element-button"><?php esc_html_e('Our community', 'carlyle-block-theme');?></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"border":{"radius":"0px","width":"0px","style":"none"},"color":{"gradient":"linear-gradient(180deg,rgb(255,255,255) 54%,rgb(233,233,233) 54%)"},"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group has-background" style="border-style:none;border-width:0px;border-radius:0px;background:linear-gradient(180deg,rgb(255,255,255) 54%,rgb(233,233,233) 54%);padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60","left":"var:preset|spacing|10","right":"var:preset|spacing|10"}},"border":{"radius":"20px","width":"1px"}},"backgroundColor":"base","borderColor":"neutral","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignwide has-border-color has-neutral-border-color has-base-background-color has-background" style="border-width:1px;border-radius:20px;padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--10);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--10)"><!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"right":"var:preset|spacing|30","left":"var:preset|spacing|30"}}},"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
<div class="wp-block-group alignwide" style="padding-right:var(--wp--preset--spacing--30);padding-left:var(--wp--preset--spacing--30)"><!-- wp:heading -->
<h2 class="wp-block-heading"><?php esc_html_e('Featured AMENITIES', 'carlyle-block-theme');?></h2>
<!-- /wp:heading -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"fontSize":"tiny"} -->
<div class="wp-block-button has-custom-font-size has-tiny-font-size"><a class="wp-block-button__link wp-element-button"><?php esc_html_e('View All', 'carlyle-block-theme');?></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->

<!-- wp:columns {"verticalAlignment":"center","style":{"spacing":{"padding":{"right":"var:preset|spacing|80","left":"var:preset|spacing|80","top":"var:preset|spacing|30","bottom":"var:preset|spacing|30"}}}} -->
<div class="wp-block-columns are-vertically-aligned-center" style="padding-top:var(--wp--preset--spacing--30);padding-right:var(--wp--preset--spacing--80);padding-bottom:var(--wp--preset--spacing--30);padding-left:var(--wp--preset--spacing--80)"><!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:image {"width":"116px","height":"auto","scale":"cover","sizeSlug":"medium","linkDestination":"none"} -->
<figure class="wp-block-image size-medium is-resized"><img src="<?php echo esc_url( get_stylesheet_directory_uri() ); ?>/assets/images/RCDA-Amenity-Icons-Pet-Friendly-300x300.png" alt="<?php esc_html_e('', 'carlyle-block-theme');?>" style="object-fit:cover;width:116px;height:auto"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":4,"style":{"elements":{"link":{"color":{"text":"var:preset|color|accent"}}}},"textColor":"accent","fontSize":"tiny"} -->
<h4 class="wp-block-heading has-accent-color has-text-color has-link-color has-tiny-font-size"><?php esc_html_e('Green Space', 'carlyle-block-theme');?></h4>
<!-- /wp:heading --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:image {"width":"118px","height":"auto","sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="<?php echo esc_url( get_stylesheet_directory_uri() ); ?>/assets/images/RCDA-Amenity-Icons-Green-Space.png" alt="<?php esc_html_e('', 'carlyle-block-theme');?>" style="width:118px;height:auto"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":4,"style":{"elements":{"link":{"color":{"text":"var:preset|color|accent"}}}},"textColor":"accent","fontSize":"tiny"} -->
<h4 class="wp-block-heading has-accent-color has-text-color has-link-color has-tiny-font-size"><?php esc_html_e('Pet Friendly', 'carlyle-block-theme');?></h4>
<!-- /wp:heading --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:image {"width":"114px","height":"auto","sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="<?php echo esc_url( get_stylesheet_directory_uri() ); ?>/assets/images/RCDA-Amenity-Icons-Events.png" alt="<?php esc_html_e('', 'carlyle-block-theme');?>" style="width:114px;height:auto"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":4,"style":{"elements":{"link":{"color":{"text":"var:preset|color|accent"}}}},"textColor":"accent","fontSize":"tiny"} -->
<h4 class="wp-block-heading has-accent-color has-text-color has-link-color has-tiny-font-size"><?php esc_html_e('Community Events', 'carlyle-block-theme');?></h4>
<!-- /wp:heading --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80"},"margin":{"top":"0px","bottom":"0px"}}},"backgroundColor":"neutral","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-neutral-background-color has-background" style="margin-top:0px;margin-bottom:0px;padding-top:var(--wp--preset--spacing--80);padding-bottom:var(--wp--preset--spacing--80)"><!-- wp:group {"align":"wide","layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group alignwide"><!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:heading -->
<h2 class="wp-block-heading"><?php esc_html_e('DISCOVER EVERYTHING COEUR D’ALENE HAS TO OFFER!', 'carlyle-block-theme');?></h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"tiny"} -->
<p class="has-tiny-font-size"><?php esc_html_e('Whether you’re looking forward to a day on the nearby Coeur d’Alene Lake or wish to shop till you drop, our 55+ community is the perfect location. We are situated on Ramsey Road just north of the Coeur d’Alene Public Golf Club, where U.S. Rte. 95 and I-90 meet. This fantastic area features many top-notch dining options to make your mouth water and shopping that ensures you have everything you need – no matter the season. Public services, ride-sharing, and local access to veterinarians, dentists, and medical professionals are easily accessible from the community entrance.', 'carlyle-block-theme');?></p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"textColor":"accent","style":{"elements":{"link":{"color":{"text":"var:preset|color|accent"}}},"typography":{"fontStyle":"normal","fontWeight":"700"},"color":{"background":"#7e9c8f73"}},"fontSize":"tiny"} -->
<div class="wp-block-button has-custom-font-size has-tiny-font-size" style="font-style:normal;font-weight:700"><a class="wp-block-button__link has-accent-color has-text-color has-background has-link-color wp-element-button" style="background-color:#7e9c8f73"><?php esc_html_e('Explore Coeur D’Alene', 'carlyle-block-theme');?></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->

<!-- wp:image {"width":"564px","height":"auto","sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="<?php echo esc_url( get_stylesheet_directory_uri() ); ?>/assets/images/GettyImages-956560038.jpg" alt="<?php esc_html_e('', 'carlyle-block-theme');?>" style="width:564px;height:auto"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"border":{"radius":"0px","width":"0px","style":"none"},"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="border-style:none;border-width:0px;border-radius:0px;padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|30","right":"var:preset|spacing|30"}},"border":{"radius":"20px","width":"50px"},"elements":{"link":{"color":{"text":"var:preset|color|base"}}}},"backgroundColor":"accent","textColor":"base","borderColor":"accent-3","layout":{"type":"constrained","justifyContent":"center"}} -->
<div class="wp-block-group alignwide has-border-color has-accent-3-border-color has-base-color has-accent-background-color has-text-color has-background has-link-color" style="border-width:50px;border-radius:20px;padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--30);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--30)"><!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"style":{"elements":{"link":{"color":{"text":"var:preset|color|base"}}}},"textColor":"base","fontSize":"large"} -->
<h2 class="wp-block-heading has-base-color has-text-color has-link-color has-large-font-size"><?php esc_html_e('KEEP ME IN THE LOOP', 'carlyle-block-theme');?></h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"tiny"} -->
<p class="has-tiny-font-size"><?php esc_html_e('We’ll share the latest listings and specials from our 55+ community with a variety of move-in ready manufactured homes for sale.', 'carlyle-block-theme');?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:pattern {"slug":"carlyle-block-theme/features-socials"} /-->

<!-- wp:template-part {"slug":"footer"} /-->