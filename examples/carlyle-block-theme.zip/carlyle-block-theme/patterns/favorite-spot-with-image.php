<?php
/**
 * Title: Favorite Spot with Image
 * Slug: carlyle-block-theme/favorite-spot-with-image
 * Categories: carlyleblocktheme-content
 * Viewport Width: 1240
 * Inserter: true
 */
?>
<!-- wp:group {"layout":{"type":"constrained","wideSize":"","contentSize":"1224px"}} -->
<div class="wp-block-group">
    <!-- wp:group {"layout":{"type":"constrained","contentSize":"","wideSize":"1224px"}} -->
    <div class="wp-block-group">
        <!-- wp:columns -->
            <div class="wp-block-columns">
                <!-- wp:column {"width":"66.66%"} -->
                <div class="wp-block-column" style="flex-basis:66.66%">
                    <!-- wp:image {"id":32,"aspectRatio":"16/9","scale":"cover","sizeSlug":"full","linkDestination":"none","align":"center","style":{"border":{"radius":"50px"}}} -->
                    <figure class="wp-block-image aligncenter size-full has-custom-border"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/favorite-spot-1-1500.jpg" alt="" class="wp-image-32" style="border-radius:50px;aspect-ratio:16/9;object-fit:cover"/></figure>
                    <!-- /wp:image -->
                </div>
                <!-- /wp:column -->

                <!-- wp:column {"verticalAlignment":"center","width":"33.33%","layout":{"type":"constrained"}} -->
                <div class="wp-block-column is-vertically-aligned-center" style="flex-basis:33.33%">
                    <!-- wp:group {"style":{"border":{"radius":"50px"},"spacing":{"blockGap":"0","padding":{"right":"var:preset|spacing|30","left":"var:preset|spacing|30","top":"var:preset|spacing|40","bottom":"var:preset|spacing|40"}}},"backgroundColor":"accent","layout":{"type":"constrained","justifyContent":"center"}} -->
                        <div class="wp-block-group has-accent-background-color has-background" style="border-radius:50px;padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--30);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--30)">
                            <!-- wp:heading {"style":{"elements":{"link":{"color":{"text":"var:preset|color|base"}}}},"textColor":"base"} -->
                            <h2 class="wp-block-heading has-base-color has-text-color has-link-color"><strong>ARIZONA-SONORAN DESERT</strong></h2>
                            <!-- /wp:heading -->
            
                            <!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|base"}}}},"textColor":"base"} -->
                            <p class="has-base-color has-text-color has-link-color">The Arizona Sonoran Desert captivates with its vast landscapes, dramatic saguaro cacti, and vibrant sunsets, offering a serene yet striking backdrop to explore and admire.</p>
                            <!-- /wp:paragraph -->
                        </div>
                    <!-- /wp:group -->
                </div>
                <!-- /wp:column -->
            </div>
            <!-- /wp:columns -->
        </div>
    <!-- /wp:group -->
</div>
<!-- /wp:group -->