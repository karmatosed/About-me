<?php
/**
 * Title: Featured Services
 * Slug: carlyle-block-theme/featured-services
 * Description:
 * Categories: carlyleblocktheme-theme
 * Keywords:
 * Viewport Width: 1240
 * Block Types:
 * Post Types:
 * Inserter: true
 */
?>
<!-- wp:group {"style":{"border":{"radius":"0px","width":"0px","style":"none"},"color":{"gradient":"linear-gradient(180deg,rgb(255,255,255) 54%,rgb(233,233,233) 54%)"},"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group has-background" style="border-style:none;border-width:0px;border-radius:0px;background:linear-gradient(180deg,rgb(255,255,255) 54%,rgb(233,233,233) 54%);padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60","left":"var:preset|spacing|10","right":"var:preset|spacing|10"}},"border":{"radius":"20px","width":"1px"}},"backgroundColor":"base","borderColor":"neutral","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignwide has-border-color has-neutral-border-color has-base-background-color has-background" style="border-width:1px;border-radius:20px;padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--10);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--10)"><!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"right":"var:preset|spacing|30","left":"var:preset|spacing|30"}}},"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
<div class="wp-block-group alignwide" style="padding-right:var(--wp--preset--spacing--30);padding-left:var(--wp--preset--spacing--30)"><!-- wp:heading -->
<h2 class="wp-block-heading">Featured AMENITIES</h2>
<!-- /wp:heading -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"fontSize":"tiny"} -->
<div class="wp-block-button has-custom-font-size has-tiny-font-size"><a class="wp-block-button__link wp-element-button">View All</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->

<!-- wp:columns {"verticalAlignment":"center","style":{"spacing":{"padding":{"right":"var:preset|spacing|80","left":"var:preset|spacing|80","top":"var:preset|spacing|30","bottom":"var:preset|spacing|30"}}}} -->
<div class="wp-block-columns are-vertically-aligned-center" style="padding-top:var(--wp--preset--spacing--30);padding-right:var(--wp--preset--spacing--80);padding-bottom:var(--wp--preset--spacing--30);padding-left:var(--wp--preset--spacing--80)"><!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:image {"width":"116px","height":"auto","scale":"cover","sizeSlug":"medium","linkDestination":"none"} -->
<figure class="wp-block-image size-medium is-resized"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/RCDA-Amenity-Icons-Pet-Friendly-300x300.png" alt="" style="object-fit:cover;width:116px;height:auto"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":4,"style":{"elements":{"link":{"color":{"text":"var:preset|color|accent"}}}},"textColor":"accent","fontSize":"tiny"} -->
<h4 class="wp-block-heading has-accent-color has-text-color has-link-color has-tiny-font-size">Green Space</h4>
<!-- /wp:heading --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:image {"width":"118px","height":"auto","sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/RCDA-Amenity-Icons-Green-Space.png" alt="" style="width:118px;height:auto"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":4,"style":{"elements":{"link":{"color":{"text":"var:preset|color|accent"}}}},"textColor":"accent","fontSize":"tiny"} -->
<h4 class="wp-block-heading has-accent-color has-text-color has-link-color has-tiny-font-size">Pet Friendly</h4>
<!-- /wp:heading --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:image {"width":"114px","height":"auto","sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/RCDA-Amenity-Icons-Events.png" alt="" style="width:114px;height:auto"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":4,"style":{"elements":{"link":{"color":{"text":"var:preset|color|accent"}}}},"textColor":"accent","fontSize":"tiny"} -->
<h4 class="wp-block-heading has-accent-color has-text-color has-link-color has-tiny-font-size">Community Events</h4>
<!-- /wp:heading --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->