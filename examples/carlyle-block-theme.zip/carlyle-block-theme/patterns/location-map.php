<?php
/**
 * Title: Location Map
 * Slug: carlyle-block-theme/location-map
 * Description:
 * Categories: carlyleblocktheme-content
 * Keywords:
 * Viewport Width: 1240
 * Block Types:
 * Post Types:
 * Inserter: true
 */
?>
<!-- wp:group {"layout":{"type":"constrained","contentSize":"1024px"}} -->
<div class="wp-block-group">
    <!-- wp:group {"style":{"border":{"radius":"50px"},"layout":{"type":"constrained","contentSize":"100%"},"overflow":"hidden"},"layout":{"type":"constrained","contentSize":"1024px"}} -->
    <div class="wp-block-group" style="border-radius:50px">
        <!-- wp:html -->
        <iframe
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2827.7245221062534!2d-116.80923378446643!3d47.7136933791909!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x5361eec50b315d27%3A0xd53b1a6796b06b14!2s4502%20N%20Ramsey%20Rd%2C%20Coeur%20d&#39;Alene%2C%20ID%2083815%2C%20USA!5e0!3m2!1sen!2sus!4v1694174792485!5m2!1sen!2sus"
        width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade">
        </iframe>
        <!-- /wp:html -->
    </div>
    <!-- /wp:group -->
</div>
<!-- /wp:group -->