<?php
/**
 * Title: Contact Page Form
 * Slug: carlyle-block-theme/contact-form
 * Description:
 * Categories: carlyleblocktheme-content
 * Keywords:
 * Viewport Width: 1240
 * Block Types:
 * Post Types:
 * Inserter: true
 */
?>
<!-- wp:group {"layout":{"type":"constrained","contentSize":"1024px"}} -->
<div class="wp-block-group">
    <!-- wp:heading {"textAlign":"center"} -->
    <h2 class="wp-block-heading has-text-align-center">Send us a message</h2>
    <!-- /wp:heading -->

    <!-- wp:gravityforms/form {"formId":"2","title":false,"description":false,"inputPrimaryColor":"#204ce5"} /-->
</div>
<!-- /wp:group -->