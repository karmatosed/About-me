<?php
/**
 * Title: Contact Hero
 * Slug: carlyle-block-theme/contact-hero
 * Description:
 * Categories: carlyleblocktheme-hero
 * Keywords:
 * Viewport Width: 1240
 * Block Types:
 * Post Types:
 * Inserter: true
 */
?>
<!-- wp:group {"align":"full","layout":{"type":"default"}} -->
<div class="wp-block-group alignfull">
    <!-- wp:cover {"url":"<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/placeholder-image-brandon-jacoby.jpg","id":32,"dimRatio":0,"customOverlayColor":"#919287","isUserOverlayColor":true,"minHeight":500,"minHeightUnit":"px","isDark":false,"align":"full","style":{"border":{"radius":{"bottomLeft":"50px","bottomRight":"50px"}}}} -->
    <div class="wp-block-cover alignfull is-light" style="border-bottom-left-radius:50px;border-bottom-right-radius:50px;min-height:500px">
        <span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim" style="background-color:#919287"></span>
        <img class="wp-block-cover__image-background wp-image-32" alt="" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/placeholder-image-brandon-jacoby.jpg" data-object-fit="cover"/>
        <div class="wp-block-cover__inner-container">

            <!-- wp:group {"layout":{"type":"constrained","contentSize":"1024px"}} -->
            <div class="wp-block-group">
                <!-- wp:heading {"textAlign":"left","level":1,"style":{"elements":{"link":{"color":{"text":"var:preset|color|base"}}}},"textColor":"base","fontSize":"xxx-large"} -->
                <h1 class="wp-block-heading has-text-align-left has-base-color has-text-color has-link-color has-xxx-large-font-size">Contact Us</h1>
                <!-- /wp:heading -->
            </div>
            <!-- /wp:group -->

        </div>
    </div>
    <!-- /wp:cover -->
</div>
<!-- /wp:group -->