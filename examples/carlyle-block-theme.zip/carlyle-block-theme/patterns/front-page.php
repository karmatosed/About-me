<?php
/**
 * Title: front-page
 * Slug: carlyle-block-theme/front-page
 * Categories: hidden
 * Inserter: no
 */
?>
<!-- wp:template-part {"slug":"header","tagName":"header"} /-->

<!-- wp:pattern {"slug":"carlyle-block-theme/featured-cover"} /-->

<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|20","right":"var:preset|spacing|20"},"margin":{"top":"0px","bottom":"0px"}}},"backgroundColor":"neutral","layout":{"type":"constrained","contentSize":"1240px"}} -->
<div class="wp-block-group has-neutral-background-color has-background" style="margin-top:0px;margin-bottom:0px;padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--20);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--20)"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
<div class="wp-block-group"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:heading {"fontSize":"x-large"} -->
<h2 class="wp-block-heading has-x-large-font-size"><?php esc_html_e('FEATURED HOMES ', 'carlyle-block-theme');?></h2>
<!-- /wp:heading -->

<!-- wp:image {"width":"47px","height":"auto","scale":"cover","sizeSlug":"thumbnail","linkDestination":"none"} -->
<figure class="wp-block-image size-thumbnail is-resized"><img src="<?php echo esc_url( get_stylesheet_directory_uri() ); ?>/assets/images/ridgeview-tree-150x150.png" alt="<?php esc_html_e('', 'carlyle-block-theme');?>" style="object-fit:cover;width:47px;height:auto"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"fontSize":"tiny"} -->
<div class="wp-block-button has-custom-font-size has-tiny-font-size"><a class="wp-block-button__link wp-element-button"><?php esc_html_e('View all Homes', 'carlyle-block-theme');?></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->

<!-- wp:shortcode -->
[carlyle_home_listings home_count=3]
<!-- /wp:shortcode --></div>
<!-- /wp:group -->

<!-- wp:pattern {"slug":"carlyle-block-theme/content-image-left"} /-->
<!-- wp:pattern {"slug":"carlyle-block-theme/featured-services"} /-->
 <!-- wp:pattern {"slug":"carlyle-block-theme/content-image-right"} /-->
 <!-- wp:pattern {"slug":"carlyle-block-theme/contact"} /-->
 <!-- wp:pattern {"slug":"carlyle-block-theme/featured-socials"} /-->

<!-- wp:template-part {"slug":"footer"} /-->