<?php
/**
 * Title: footer
 * Slug: carlyle-block-theme/footer
 * Categories: hidden
 * Inserter: no
 */
?>
<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"},"margin":{"top":"0px","bottom":"0px"},"blockGap":"0"},"elements":{"link":{"color":{"text":"var:preset|color|base"}}},"color":{"background":"#13322b"}},"textColor":"base","fontSize":"tiny","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-base-color has-text-color has-background has-link-color has-tiny-font-size" style="background-color:#13322b;margin-top:0px;margin-bottom:0px;padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide"><!-- wp:column {"width":"20%"} -->
<div class="wp-block-column" style="flex-basis:20%"><!-- wp:group {"style":{"dimensions":{"minHeight":""},"layout":{"selfStretch":"fit","flexSize":null}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group"><!-- wp:site-logo {"width":169,"shouldSyncIcon":true,"style":{"layout":{"selfStretch":"fit","flexSize":null}}} /--></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"80%","style":{"elements":{"link":{"color":{"text":"var:preset|color|base"}}}},"textColor":"base"} -->
<div class="wp-block-column has-base-color has-text-color has-link-color" style="flex-basis:80%"><!-- wp:group {"fontSize":"tiny","layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between","verticalAlignment":"top"}} -->
<div class="wp-block-group has-tiny-font-size"><!-- wp:group {"layout":{"type":"flex","orientation":"vertical","justifyContent":"stretch"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":3,"className":"has-medium-font-size","style":{"typography":{"fontStyle":"normal","fontWeight":"600","textTransform":"uppercase"},"elements":{"link":{"color":{"text":"var:preset|color|base"}}}},"textColor":"base","fontSize":"tiny","fontFamily":"inter"} -->
<h3 class="wp-block-heading has-medium-font-size has-base-color has-text-color has-link-color has-inter-font-family has-tiny-font-size" style="font-style:normal;font-weight:600;text-transform:uppercase"><?php esc_html_e('QUICK LINKS', 'carlyle-block-theme');?></h3>
<!-- /wp:heading -->

<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|10"}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group"><!-- wp:navigation {"overlayMenu":"never","style":{"typography":{"fontStyle":"normal","fontWeight":"400"},"spacing":{"blockGap":"var:preset|spacing|10"}},"fontSize":"tiny","layout":{"type":"flex","orientation":"vertical"}} -->
<!-- wp:navigation-link {"label":"Team","url":"#"} /-->

<!-- wp:navigation-link {"label":"History","url":"#"} /-->

<!-- wp:navigation-link {"label":"Careers","url":"#"} /-->
<!-- /wp:navigation --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"layout":{"type":"flex","orientation":"vertical","justifyContent":"stretch"}} -->
<div class="wp-block-group"><!-- wp:heading {"className":"has-medium-font-size","style":{"typography":{"fontStyle":"normal","fontWeight":"600","textTransform":"uppercase"},"elements":{"link":{"color":{"text":"var:preset|color|base"}}}},"textColor":"base","fontSize":"tiny","fontFamily":"inter"} -->
<h2 class="wp-block-heading has-medium-font-size has-base-color has-text-color has-link-color has-inter-font-family has-tiny-font-size" style="font-style:normal;font-weight:600;text-transform:uppercase"><?php esc_html_e('Privacy POLICY', 'carlyle-block-theme');?></h2>
<!-- /wp:heading -->

<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|10"}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group"><!-- wp:navigation {"overlayMenu":"never","style":{"typography":{"fontStyle":"normal","fontWeight":"400"},"spacing":{"blockGap":"var:preset|spacing|10"}},"fontSize":"tiny","layout":{"type":"flex","orientation":"vertical"}} -->
<!-- wp:navigation-link {"label":"Privacy Policy","url":"#"} /-->

<!-- wp:navigation-link {"label":"Terms and Conditions","url":"#"} /-->

<!-- wp:navigation-link {"label":"Contact Us","url":"#"} /-->
<!-- /wp:navigation --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"layout":{"type":"flex","orientation":"vertical","justifyContent":"stretch"}} -->
<div class="wp-block-group"><!-- wp:heading {"className":"has-medium-font-size","style":{"typography":{"fontStyle":"normal","fontWeight":"600","textTransform":"uppercase"},"elements":{"link":{"color":{"text":"var:preset|color|base"}}}},"textColor":"base","fontSize":"tiny","fontFamily":"inter"} -->
<h2 class="wp-block-heading has-medium-font-size has-base-color has-text-color has-link-color has-inter-font-family has-tiny-font-size" style="font-style:normal;font-weight:600;text-transform:uppercase"><?php esc_html_e('CONTACT', 'carlyle-block-theme');?></h2>
<!-- /wp:heading -->

<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|10"}},"fontSize":"tiny","layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group has-tiny-font-size"><!-- wp:paragraph -->
<p><?php esc_html_e('email@email.com', 'carlyle-block-theme');?></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><?php esc_html_e('tel:208-845-9099&gt;208-845-9099', 'carlyle-block-theme');?></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><?php esc_html_e('4502 N. Ramsey Road Coeur', 'carlyle-block-theme');?></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><?php esc_html_e('d’Alene, ID 83815', 'carlyle-block-theme');?></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><?php esc_html_e('Monday – Friday 9:00am – 4:00pm', 'carlyle-block-theme');?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"elements":{"link":{"color":{"text":"var:preset|color|base"}}},"spacing":{"padding":{"top":"var:preset|spacing|20","bottom":"var:preset|spacing|20"},"margin":{"top":"0px","bottom":"0px"}}},"backgroundColor":"accent-3","textColor":"base","fontSize":"tiny","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-base-color has-accent-3-background-color has-text-color has-background has-link-color has-tiny-font-size" style="margin-top:0px;margin-bottom:0px;padding-top:var(--wp--preset--spacing--20);padding-bottom:var(--wp--preset--spacing--20)"><!-- wp:paragraph {"align":"center","style":{"elements":{"link":{"color":{"text":"var:preset|color|neutral"},":hover":{"color":{"text":"var:preset|color|base"}}}}},"textColor":"base","fontSize":"tiny"} -->
<p class="has-text-align-center has-base-color has-text-color has-link-color has-tiny-font-size"><?php esc_html_e('©2024. Ridgeview at Coeur D’Alene. All rights reserved.', 'carlyle-block-theme');?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->