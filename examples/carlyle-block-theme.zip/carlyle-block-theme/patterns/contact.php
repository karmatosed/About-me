<?php
/**
 * Title: Contact Form
 * Slug: carlyle-block-theme/contact
 * Description:
 * Categories: carlyleblocktheme-content
 * Keywords:
 * Viewport Width: 1240
 * Block Types:
 * Post Types:
 * Inserter: true
 */
?>
<!-- wp:group {"align":"wide","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignwide"><!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|30","right":"var:preset|spacing|30"}},"border":{"radius":"20px","width":"50px"},"elements":{"link":{"color":{"text":"var:preset|color|base"}}}},"backgroundColor":"accent","textColor":"base","borderColor":"accent-3","layout":{"type":"constrained","justifyContent":"center"}} -->
<div class="wp-block-group alignwide has-border-color has-accent-3-border-color has-base-color has-accent-background-color has-text-color has-background has-link-color" style="border-width:50px;border-radius:20px;padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--30);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--30)"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"style":{"elements":{"link":{"color":{"text":"var:preset|color|base"}}}},"textColor":"base","fontSize":"large"} -->
<h2 class="wp-block-heading has-base-color has-text-color has-link-color has-large-font-size">KEEP ME IN THE LOOP</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"tiny"} -->
<p class="has-tiny-font-size">We’ll share the latest listings and specials from our 55+ community with a variety of move-in ready manufactured homes for sale.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->