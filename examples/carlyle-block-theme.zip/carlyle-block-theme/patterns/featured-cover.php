<?php
/**
 * Title: Featured Cover
 * Slug: carlyle-block-theme/featured-cover
 * Description:
 * Categories: carlyleblocktheme-hero
 * Keywords:
 * Viewport Width: 1240
 * Block Types:
 * Post Types:
 * Inserter: true
 */
?>
<!-- wp:group {"style":{"spacing":{"margin":{"top":"0px","bottom":"0px"}}},"backgroundColor":"neutral","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-neutral-background-color has-background" style="margin-top:0px;margin-bottom:0px"><!-- wp:cover {"url":"<?php echo esc_url( get_template_directory_uri() ); ?>/assets/videos/GettyImages-629177256.mp4","dimRatio":60,"overlayColor":"contrast","isUserOverlayColor":true,"backgroundType":"video","minHeight":100,"minHeightUnit":"vh","align":"full","style":{"spacing":{"margin":{"top":"0px","bottom":"0px"},"padding":{"top":"var:preset|spacing|30","bottom":"var:preset|spacing|30"}},"border":{"width":"1px","color":"#ffffff","radius":{"bottomLeft":"50px","bottomRight":"50px"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-cover alignfull has-border-color" style="border-color:#ffffff;border-width:1px;border-bottom-left-radius:50px;border-bottom-right-radius:50px;margin-top:0px;margin-bottom:0px;padding-top:var(--wp--preset--spacing--30);padding-bottom:var(--wp--preset--spacing--30);min-height:100vh"><span aria-hidden="true" class="wp-block-cover__background has-contrast-background-color has-background-dim-60 has-background-dim"></span><video class="wp-block-cover__video-background intrinsic-ignore" autoplay muted loop playsinline src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/videos/GettyImages-629177256.mp4" data-object-fit="cover"></video><div class="wp-block-cover__inner-container"><!-- wp:group {"align":"wide","layout":{"type":"constrained","justifyContent":"left"}} -->
<div class="wp-block-group alignwide"><!-- wp:heading {"level":1,"style":{"elements":{"link":{"color":{"text":"var:preset|color|base"}}}},"textColor":"base"} -->
<h1 class="wp-block-heading has-base-color has-text-color has-link-color">Embrace the Allure of 55+ Living</h1>
<!-- /wp:heading -->

<!-- wp:buttons {"fontSize":"tiny"} -->
<div class="wp-block-buttons has-custom-font-size has-tiny-font-size"><!-- wp:button {"backgroundColor":"accent"} -->
<div class="wp-block-button"><a class="wp-block-button__link has-accent-background-color has-background wp-element-button">Our Listings</a></div>
<!-- /wp:button -->

<!-- wp:button {"textColor":"contrast","style":{"color":{"background":"#e8e8e8bf"},"elements":{"link":{"color":{"text":"var:preset|color|contrast"}}}},"fontFamily":"graphik"} -->
<div class="wp-block-button has-graphik-font-family"><a class="wp-block-button__link has-contrast-color has-text-color has-background has-link-color wp-element-button" style="background-color:#e8e8e8bf">Contact Us</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div></div>
<!-- /wp:cover --></div>
<!-- /wp:group -->