<?php
/**
 * Title: Featured Coverstrip
 * Slug: carlyle-block-theme/featured-coverstrip
 * Description:
 * Categories: carlyleblocktheme-hero
 * Keywords:
 * Viewport Width: 1240
 * Block Types:
 * Post Types:
 * Inserter: true
 */
?>

<!-- wp:group {"metadata":{"categories":["carlyleblocktheme-hero"],"patternName":"carlyle-block-theme/featured-coverstrip","name":"Featured Coverstrip"},"style":{"spacing":{"margin":{"top":"0px","bottom":"0px"}}},"backgroundColor":"neutral","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-neutral-background-color has-background" style="margin-top:0px;margin-bottom:0px"><!-- wp:cover {"url":"<?php echo esc_url( get_template_directory_uri() ); ?>/assets/videos/GettyImages-629177256.mp4","dimRatio":80,"isUserOverlayColor":true,"backgroundType":"video","minHeight":366,"minHeightUnit":"px","customGradient":"linear-gradient(90deg,rgb(19,50,43) 0%,rgb(19,50,43) 39%,rgba(255,255,255,0) 39%)","align":"full","style":{"spacing":{"margin":{"top":"0px","bottom":"0px"},"padding":{"top":"var:preset|spacing|30","bottom":"var:preset|spacing|30"}},"border":{"width":"1px","color":"#ffffff","radius":{"bottomLeft":"50px","bottomRight":"50px"}},"elements":{"link":{"color":{"text":"var:preset|color|accent"}}}},"textColor":"accent","layout":{"type":"constrained"}} -->
<div class="wp-block-cover alignfull has-border-color has-accent-color has-text-color has-link-color" style="border-color:#ffffff;border-width:1px;border-bottom-left-radius:50px;border-bottom-right-radius:50px;margin-top:0px;margin-bottom:0px;padding-top:var(--wp--preset--spacing--30);padding-bottom:var(--wp--preset--spacing--30);min-height:366px"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-80 has-background-dim wp-block-cover__gradient-background has-background-gradient" style="background:linear-gradient(90deg,rgb(19,50,43) 0%,rgb(19,50,43) 39%,rgba(255,255,255,0) 39%)"></span><video class="wp-block-cover__video-background intrinsic-ignore" autoplay muted loop playsinline src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/videos/GettyImages-629177256.mp4" data-object-fit="cover"></video><div class="wp-block-cover__inner-container"><!-- wp:group {"align":"wide","layout":{"type":"constrained","justifyContent":"left"}} -->
<div class="wp-block-group alignwide"><!-- wp:heading {"level":1,"style":{"elements":{"link":{"color":{"text":"var:preset|color|base"}}}},"textColor":"base"} -->
<h1 class="wp-block-heading has-base-color has-text-color has-link-color">Lifestyle</h1>
<!-- /wp:heading --></div>
<!-- /wp:group --></div></div>
<!-- /wp:cover --></div>
<!-- /wp:group -->