<?php
/**
 * Title: Featured Ammenities
 * Slug: carlyle-block-theme/featured-ammenities
 * Description:
 * Categories: carlyleblocktheme-hero
 * Keywords:
 * Viewport Width: 1240
 * Block Types:
 * Post Types:
 * Inserter: true
 */
?>

<!-- wp:group {"metadata":{"categories":["carlyleblocktheme-hero"],"patternName":"carlyle-block-theme/featured-ammenities","name":"Featured Ammenities"},"style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="padding-top:var(--wp--preset--spacing--80);padding-bottom:var(--wp--preset--spacing--80)"><!-- wp:group {"align":"wide","layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
<div class="wp-block-group alignwide"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:heading {"fontSize":"x-large"} -->
<h2 class="wp-block-heading has-x-large-font-size">OUR AMMENITIES</h2>
<!-- /wp:heading -->

<!-- wp:image {"width":"47px","height":"auto","scale":"cover","sizeSlug":"thumbnail","linkDestination":"none"} -->
<figure class="wp-block-image size-thumbnail is-resized"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/ridgeview-tree-150x150.png" alt="" style="object-fit:cover;width:47px;height:auto"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"fontSize":"tiny"} -->
<div class="wp-block-button has-custom-font-size has-tiny-font-size"><a class="wp-block-button__link wp-element-button">View all Homes</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->

<!-- wp:group {"align":"wide","layout":{"type":"grid","minimumColumnWidth":"12rem"}} -->
<div class="wp-block-group alignwide"><!-- wp:group {"layout":{"type":"flex","orientation":"vertical","justifyContent":"center"}} -->
<div class="wp-block-group"><!-- wp:image {"id":8,"sizeSlug":"full","linkDestination":"none","className":"is-style-image-partialrounding","style":{"layout":{"columnSpan":1,"rowSpan":1}}} -->
<figure class="wp-block-image size-full is-style-image-partialrounding"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/Listing-8845-Photo-da013129-1b10-459b-b67c-2e77c6ade6c4.jpg" alt="" class="wp-image-8"/></figure>
<!-- /wp:image -->

<!-- wp:outermost/icon-block /-->

<!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading"></h4>
<!-- /wp:heading --></div>
<!-- /wp:group -->

<!-- wp:group {"layout":{"type":"flex","orientation":"vertical","justifyContent":"center"}} -->
<div class="wp-block-group"><!-- wp:image {"id":8,"sizeSlug":"full","linkDestination":"none","className":"is-style-image-partialrounding","style":{"layout":{"columnSpan":1,"rowSpan":1}}} -->
<figure class="wp-block-image size-full is-style-image-partialrounding"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/Listing-8845-Photo-da013129-1b10-459b-b67c-2e77c6ade6c4.jpg" alt="" class="wp-image-8"/></figure>
<!-- /wp:image -->

<!-- wp:outermost/icon-block /-->

<!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading"></h4>
<!-- /wp:heading --></div>
<!-- /wp:group -->

<!-- wp:group {"layout":{"type":"flex","orientation":"vertical","justifyContent":"center"}} -->
<div class="wp-block-group"><!-- wp:image {"id":8,"sizeSlug":"full","linkDestination":"none","className":"is-style-image-partialrounding","style":{"layout":{"columnSpan":1,"rowSpan":1}}} -->
<figure class="wp-block-image size-full is-style-image-partialrounding"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/Listing-8845-Photo-da013129-1b10-459b-b67c-2e77c6ade6c4.jpg" alt="" class="wp-image-8"/></figure>
<!-- /wp:image -->

<!-- wp:outermost/icon-block /-->

<!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading"></h4>
<!-- /wp:heading --></div>
<!-- /wp:group -->

<!-- wp:group {"layout":{"type":"flex","orientation":"vertical","justifyContent":"center"}} -->
<div class="wp-block-group"><!-- wp:image {"id":8,"sizeSlug":"full","linkDestination":"none","className":"is-style-image-partialrounding","style":{"layout":{"columnSpan":1,"rowSpan":1}}} -->
<figure class="wp-block-image size-full is-style-image-partialrounding"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/Listing-8845-Photo-da013129-1b10-459b-b67c-2e77c6ade6c4.jpg" alt="" class="wp-image-8"/></figure>
<!-- /wp:image -->

<!-- wp:outermost/icon-block /-->

<!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading"></h4>
<!-- /wp:heading --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->