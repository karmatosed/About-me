<?php
/**
 * Title: Simple Page Title
 * Slug: carlyle-block-theme/page-title-simple
 * Description: Page Title banner with base background color
 * Categories: carlyleblocktheme-hero
 * Keywords:
 * Viewport Width: 1240
 * Block Types:
 * Post Types:
 * Inserter: true
 */
?>

<!-- wp:group {"align":"full","layout":{"type":"default"}} -->
<div class="wp-block-group alignfull">
    <!-- wp:post-title {"textAlign":"center","style":{"elements":{"link":{"color":{"text":"var:preset|color|base"}}},"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|80","right":"var:preset|spacing|80"}}},"backgroundColor":"accent-3","textColor":"base","fontSize":"xx-large"} /-->
</div>
<!-- /wp:group -->