<?php
/**
 * Title: Content with Right Image Background
 * Slug: carlyle-block-theme/content-image-rightbackground
 * Categories: carlyleblocktheme-content
 * Viewport Width: 1240
 * Inserter: true
 */
?>
<!-- wp:group {"metadata":{"categories":["carlyleblocktheme-content"],"patternName":"carlyle-block-theme/content-image-right","name":"Content with Right Image"},"style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80"},"margin":{"top":"0px","bottom":"0px"}},"background":{"backgroundImage":{"url":"<?php echo esc_url( get_template_directory_uri() ); ?>/assets/placeholder.png","id":33,"source":"file","title":"placeholder"},"backgroundPosition":"50% 0"}},"backgroundColor":"base","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-base-background-color has-background" style="margin-top:0px;margin-bottom:0px;padding-top:var(--wp--preset--spacing--80);padding-bottom:var(--wp--preset--spacing--80)"><!-- wp:group {"align":"wide","layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group alignwide"><!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:image {"width":"47px","height":"auto","scale":"cover","sizeSlug":"thumbnail","linkDestination":"none"} -->
<figure class="wp-block-image size-thumbnail is-resized"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/ridgeview-tree-150x150.png" alt="" style="object-fit:cover;width:47px;height:auto"/></figure>
<!-- /wp:image -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Our Lifestyle</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"tiny"} -->
<p class="has-tiny-font-size">Whether you’re looking forward to a day on the nearby Coeur d’Alene Lake or wish to shop till you drop, our 55+ community is the perfect location. We are situated on Ramsey Road just north of the Coeur d’Alene Public Golf Club, where U.S. Rte. 95 and I-90 meet. This fantastic area features many top-notch dining options to make your mouth water and shopping that ensures you have everything you need – no matter the season. Public services, ride-sharing, and local access to veterinarians, dentists, and medical professionals are easily accessible from the community entrance.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"textColor":"accent","style":{"elements":{"link":{"color":{"text":"var:preset|color|accent"}}},"typography":{"fontStyle":"normal","fontWeight":"700"},"color":{"background":"#7e9c8f73"}},"fontSize":"tiny"} -->
<div class="wp-block-button has-custom-font-size has-tiny-font-size" style="font-style:normal;font-weight:700"><a class="wp-block-button__link has-accent-color has-text-color has-background has-link-color wp-element-button" style="background-color:#7e9c8f73">View our newsletter</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->

<!-- wp:image {"width":"564px","height":"auto","sizeSlug":"full","linkDestination":"none","className":"is-style-image-partialrounding"} -->
<figure class="wp-block-image size-full is-resized is-style-image-partialrounding"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/GettyImages-956560038.jpg" alt="" style="width:564px;height:auto"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->