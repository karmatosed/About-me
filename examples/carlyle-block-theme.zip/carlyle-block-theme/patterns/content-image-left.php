<?php
/**
 * Title: Content with Left Image
 * Slug: carlyle-block-theme/content-image-left
 * Categories: carlyleblocktheme-content
 * Viewport Width: 1240
 * Inserter: true
 */
?>
<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="padding-top:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40)"><!-- wp:group {"align":"wide","layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group alignwide"><!-- wp:image {"width":"564px","height":"auto","sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/GettyImages-956560038.jpg" alt="" style="width:564px;height:auto"/></figure>
<!-- /wp:image -->

<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:heading {"fontSize":"large"} -->
<h2 class="wp-block-heading has-large-font-size">ELEVATED MANUFACTURED HOME LIVING!&nbsp;</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"tiny"} -->
<p class="has-tiny-font-size">Nothing beats that bright blue Idaho sky!</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"fontSize":"tiny"} -->
<p class="has-tiny-font-size">When you join Ridgeview at Coeur D’Alene, you experience a welcoming manufactured home community in a great area with all the amenities you could want. Plenty of greenspaces exist to practice daily exercise, walk, picnic with neighbors, or watch grandkids play. Do you have a four-legged friend coming along for the journey? Our 55+ community is pet-friendly, ensuring your furry family member is there for every holiday, experience, and celebration.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"backgroundColor":"accent","textColor":"base","style":{"elements":{"link":{"color":{"text":"var:preset|color|base"}}}},"fontSize":"tiny"} -->
<div class="wp-block-button has-custom-font-size has-tiny-font-size"><a class="wp-block-button__link has-base-color has-accent-background-color has-text-color has-background has-link-color wp-element-button">Our community</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->