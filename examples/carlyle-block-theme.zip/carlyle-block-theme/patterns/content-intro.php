<?php
/**
 * Title: Intro Content
 * Slug: carlyle-block-theme/content-intro
 * Description:
 * Categories: carlyleblocktheme-content
 * Keywords:
 * Viewport Width: 1240
 * Block Types:
 * Post Types:
 * Inserter: true
 */
?>
<!-- wp:group {"align":"wide","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignwide">
    <!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|30","right":"var:preset|spacing|30"}},"border":{"radius":"20px","width":"0px","style":"none"},"elements":{"link":{"color":{"text":"var:preset|color|base"}}}},"backgroundColor":"accent","textColor":"base","layout":{"type":"constrained","justifyContent":"center","wideSize":"1024px"}} -->
    <div class="wp-block-group alignwide has-base-color has-accent-background-color has-text-color has-background has-link-color" style="border-style:none;border-width:0px;border-radius:20px;padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--30);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--30)">
        <!-- wp:heading {"textAlign":"center","style":{"elements":{"link":{"color":{"text":"var:preset|color|base"}}}},"textColor":"base","fontSize":"large"} -->
        <h2 class="wp-block-heading has-text-align-center has-base-color has-text-color has-link-color has-large-font-size"><strong>Where Desert Magic Meets Vibrant Spirit</strong></h2>
        <!-- /wp:heading -->

        <!-- wp:paragraph {"align":"center","fontSize":"tiny"} -->
        <p class="has-text-align-center has-tiny-font-size">Located in the heart of the Sonoran Desert, Tucson provides a distinctive mix of outdoor adventures, rich history, and artistic charm. Discover the towering cacti and stunning views of the iconic Saguaro National Park, or stroll through the historic downtown area, where vibrant adobe buildings and lively markets await. With its perpetual sunshine and welcoming atmosphere, Tucson beckons you to experience the enchantment of the desert Southwest.</p>
        <!-- /wp:paragraph -->
    </div>
    <!-- /wp:group -->
</div>
<!-- /wp:group -->