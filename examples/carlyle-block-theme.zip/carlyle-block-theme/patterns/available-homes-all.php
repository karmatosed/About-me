<?php
/**
 * Title: Available Homes
 * Slug: carlyle-block-theme/available-homes-all
 * Categories: carlyleblocktheme-content
 * Viewport Width: 1240
 * Inserter: false
 */
?>
<!-- wp:group {"layout":{"type":"constrained","contentSize":"1240px"}} -->
<div class="wp-block-group">
    <!-- wp:heading {"style":{"elements":{"link":{"color":{"text":"var:preset|color|accent-3"}}}},"textColor":"accent-3"} -->
    <h2 class="wp-block-heading has-accent-3-color has-text-color has-link-color">Available Homes</h2>
    <!-- /wp:heading -->
    
    <!-- wp:shortcode -->
    [carlyle_home_listings]
    <!-- /wp:shortcode -->
</div>
<!-- /wp:group -->