<?php
/**
 * Title: Section Heading with Image
 * Slug: carlyle-block-theme/section-heading-with-image
 * Description:
 * Categories: carlyleblocktheme-theme
 * Keywords:
 * Viewport Width: 1240
 * Block Types:
 * Post Types:
 * Inserter: true
 */
?>
<!-- wp:group {"align":"wide","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignwide">
    <!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between","wideSize":"1024px"}} -->
    <div class="wp-block-group">
        <!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->    
        <div class="wp-block-group">
            <!-- wp:heading {"fontSize":"x-large"} -->
            <h2 class="wp-block-heading has-x-large-font-size">SECTION HEADING </h2>
            <!-- /wp:heading -->

            <!-- wp:image {"width":"47px","height":"auto","scale":"cover","sizeSlug":"thumbnail","linkDestination":"none"} -->
            <figure class="wp-block-image size-thumbnail is-resized"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/ridgeview-tree-150x150.png" alt="" style="object-fit:cover;width:47px;height:auto"/></figure>
            <!-- /wp:image -->
        </div>
        <!-- /wp:group -->
    </div>
    <!-- /wp:group -->
</div>
<!-- /wp:group -->