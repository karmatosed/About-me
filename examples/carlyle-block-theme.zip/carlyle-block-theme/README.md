# Carlyle Block Theme

Custom Block Theme for Carlyle Communities

[![Deploy to the Rumspeed Theme Repository](https://github.com/rumspeed/carlyle-block-theme/actions/workflows/deploy-to-rumspeed-theme-repository-caller.yml/badge.svg)](https://github.com/rumspeed/carlyle-block-theme/actions/workflows/deploy-to-rumspeed-theme-repository-caller.yml)

---

## Deployment Steps

- [ ] Update Version number in style.css using Semantic Versioning `1.2.3`.
- [ ] Add changlog entry with matching version number.
- [ ] Commit these version number changes to the `main` branch.
- [ ] To deploy the theme, simply tag a new release with the `v1.2.3` syntax. (add "v" in front of version number)
- [ ] Once the version is tagged, check the [GitHub Actions](https://github.com/rumspeed/carlyle-block-theme/actions/new) page to see the list of actions.
- [ ] Click on the most recent action to verify it ran successfully. Be sure to open up the Action to see if all four actions pass.
- [ ] From here, you can view themes on the target website to check the theme version matches the release version.
- [ ] Future tagged versions will be deployed automatically. ✨
