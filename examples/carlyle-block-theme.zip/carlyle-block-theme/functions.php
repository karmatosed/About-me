<?php


// **************************************
// ***   Load the auto-update class   ***
// **************************************
// ******************************************************
// ***   FUNCTION NAME MUST BE UNIQUE TO THIS THEME  ***
// ******************************************************
add_action( 'init', 'carlyleblocktheme_activate_auto_update' );
function carlyleblocktheme_activate_auto_update() {

    $slug           = get_stylesheet();
    $version        = $version = wp_get_theme()->get( 'Version' );
    $updater_url    = 'https://backoffice.rumspeed.com/api/wpupdater/';
    $license_user   = null; // not used for this plugin
    $license_key    = null; // not used for this plugin

    require_once ( 'rumspeed-theme-updater.php' );
    new \CarlyleBlockTheme\RumspeedThemeUpdater ( $slug, $version, $updater_url, $license_user, $license_key );
}




// **************************************
// ***  Display Theme Editor Warning  ***
// **************************************
add_action( 'admin_notices', 'carlyleblocktheme_show_theme_editor_warning' );
function carlyleblocktheme_show_theme_editor_warning() {

    $screen = get_current_screen();
    $active_theme = wp_get_theme();
    $active_theme_slug = $active_theme->get_stylesheet();
    $theme_being_edited = isset( $_GET['theme'] ) ? $_GET['theme'] : $active_theme_slug;

    if ( $screen->id === 'theme-editor' && $theme_being_edited === $active_theme_slug ) {
        echo '<div class="notice notice-warning" style="background-color: #ffebe8; border-left-color: #c00; padding: 100px 20px;">
                <p style="font-size: 22px;"><strong>Warning:</strong> Do NOT edit this theme. It is automatically deployed from the Rumspeed Theme Repository.</p>
              </div>';
    }
}


/**
 * Register pattern category.
 */
function carlyleblocktheme_register_pattern_category( $slug, $label, $description ) {
	register_block_pattern_category(
		'carlyleblocktheme-' . $slug,
		array(
			'label'       => __( $label, 'carlyle-block-theme' ),
			'description' => __( $description, 'carlyle-block-theme' ),
		)
	);
}

/**
 * Register pattern categories.
 */
function carlyleblocktheme_register_pattern_categories() {
	$categories = array(
		'content'        => array( __( 'Content', 'carlyle-block-themee' ), __( 'A collection of content patterns for Carlyle Block Theme.', 'carlyle-block-theme' ) ),
		'hero'           => array( __( 'Hero', 'carlyle-block-theme' ), __( 'A collection of hero patterns for Carlyle Block Theme.', 'carlyle-block-theme' ) ),
		'theme'          => array( __( 'Theme', 'carlyle-block-theme' ), __( 'A collection of theme patterns for Carlyle Block Theme.', 'carlyle-block-theme' ) ),
	);

	foreach ( $categories as $slug => $details ) {
		carlyleblocktheme_register_pattern_category( $slug, $details[0], $details[1] );
	}
}
add_action( 'init', 'carlyleblocktheme_register_pattern_categories' );

// TODO: Can't figure out a way to get this into the theme.json "css" section so putting it here for now
add_action('wp_head', 'carlyleblocktheme_gravity_forms_styles');
function carlyleblocktheme_gravity_forms_styles() {
    ?>
    <style type="text/css">.gform_wrapper .gform_body .gform_fields .gfield input,.gform_wrapper .gform_body .gform_fields .gfield textarea{width:100%;border:none;border-bottom:2px solid #000;padding:10px 40px 10px 0;background:none;font-size:16px;outline:none;box-sizing:border-box;transition:border-color 0.3s ease}.gform_wrapper .gform_body .gform_fields .gfield input:focus,.gform_wrapper .gform_body .gform_fields .gfield textarea:focus{border-bottom:2px solid #0073aa}.gform_wrapper .gform_body .gform_fields .gfield .input-icon{position:absolute;right:10px;top:50%;transform:translateY(-50%);font-size:18px;color:#000}.gform_wrapper .gform_body .gform_fields .gfield{position:relative}.gform_wrapper .gform_body .gform_fields .gfield textarea{height:100px}.gform_wrapper .gform_body .gform_fields .gfield{margin-bottom:20px}.gform_wrapper .gform_footer .gform_button{background-color:#3b808e;color:#fff;padding:10px 40px;border-radius:50px;border:none;cursor:pointer;font-size:16px;display:inline-flex;align-items:center;justify-content:center;position:relative;text-transform:uppercase;font-weight:700;text-align:center;transition:background-color 0.3s ease}.gform_wrapper .gform_footer .gform_button:hover{background-color:#2e6976}.gform_wrapper .gform_footer .gform_button::after{content:'\2192';font-size:16px;margin-left:10px;display:inline-block;background-color:rgb(255 255 255 / .2);border-radius:50%;padding:5px;transition:background-color 0.3s ease}.gform_wrapper .gform_footer .gform_button:hover::after{background-color:rgb(255 255 255 / .4)}</style>
    <?
}


function enqueue_slider_assets() {
    wp_enqueue_style('slider-style', get_template_directory_uri() . '/assets/block-slider/block-slider.css');
    wp_enqueue_script('slider-script', get_template_directory_uri() . '/assets/block-slider/block-slider.js', array(), null, true);
}
add_action('wp_enqueue_scripts', 'enqueue_slider_assets');

