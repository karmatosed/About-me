<?php
/**
 * Title: links
 * Slug: binaryscape/links
 * Categories: 
 */
?>
<!-- wp:paragraph {"className":"copyright-links"} -->
<p class="copyright-links">© 2018 - Powered by WordPress, puppy pictures, hugs and happy thoughts.</p>
<!-- /wp:paragraph -->