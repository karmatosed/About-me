<?php
/**
 * Title: Latest navigation
 * Slug: binaryscape/latest-navigation
 * Categories: 
 */
?>
<!-- wp:list {"className":"link-list"} -->
<ul class="link-list"><li><a href="https://tammielister.com/">Hello</a></li><li><a href="http://staging.logicalbinary.com">Writing</a></li><li><a href="https://tammielister.com/speaking/">Speaking</a></li><li><a href="http://staging.logicalbinary.com/reading-list/">Reading</a></li><li><a href="https://creategenerate.art/">Art</a></li><li><a href="https://tam.blog/">Life</a></li></ul>
<!-- /wp:list -->

<!-- wp:paragraph -->
<p></p>
<!-- /wp:paragraph -->