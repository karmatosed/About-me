<?php
/**
 * Title: New Navigation
 * Slug: binaryscape/new-navigation
 * Categories: 
 */
?>
<!-- wp:list {"className":"link-list"} -->
<ul class="link-list"><li><a href="http://staging.logicalbinary.com">Hello</a></li><li><a href="https://tam.blog">Writing</a><br></li><li><a href="http://staging.logicalbinary.com/speaking/">Speaking</a><br></li><li><a href="https://tam.blog/reading-list/">Reading</a></li><li><a href="https://creategenerate.art">Art</a><a href="https://karmalife.blog/">https://karmalife.blog/</a></li><li>Life</li></ul>
<!-- /wp:list -->