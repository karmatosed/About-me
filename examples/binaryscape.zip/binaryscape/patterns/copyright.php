<?php
/**
 * Title: copyright
 * Slug: binaryscape/copyright
 * Categories: 
 */
?>
<!-- wp:paragraph -->
<p>© 2018 - Powered by WordPress, puppy pictures, hugs and happy thoughts.</p>
<!-- /wp:paragraph -->