<?php
/**
 * Title: Footer-nav
 * Slug: binaryscape/footer-nav
 * Categories: 
 */
?>
<!-- wp:group -->
<div class="wp-block-group"><div class="wp-block-group__inner-container"><!-- wp:navigation -->
<!-- wp:navigation-link {"label":"Hello","title":"https://tammielister.com/","url":"https://tammielister.com/"} /-->

<!-- wp:navigation-link {"label":"Speaking","title":"https://tammielister.com/speaking/","url":"https://tammielister.com/speaking/"} /-->

<!-- wp:navigation-link {"label":"Sketchbook","title":"karmasketch.com","url":"http://karmasketch.com"} /-->

<!-- wp:navigation-link {"label":"Life","title":"tam.blog","url":"http://tam.blog"} /-->

<!-- wp:navigation-link {"label":"Reading list","title":"http://staging.logicalbinary.com/reading-list/","url":"http://staging.logicalbinary.com/reading-list/"} /-->

<!-- wp:navigation-link {"label":"Contact","title":"mailto:karmatosed@gmail.com","url":"mailto:karmatosed@gmail.com"} /-->
<!-- /wp:navigation -->

<!-- wp:social-links -->
<ul class="wp-block-social-links"><!-- wp:social-link-twitter {"url":"https://twitter.com/karmatosed"} /-->

<!-- wp:social-link-instagram {"url":"https://www.instagram.com/karmatosed/"} /-->

<!-- wp:social-link-github {"url":"https://github.com/karmatosed/"} /-->

<!-- wp:social-link-wordpress {"url":"https://profiles.wordpress.org/karmatosed/"} /--></ul>
<!-- /wp:social-links --></div></div>
<!-- /wp:group -->